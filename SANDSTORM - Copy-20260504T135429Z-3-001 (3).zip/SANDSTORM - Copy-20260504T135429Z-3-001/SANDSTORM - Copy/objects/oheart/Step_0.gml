if (oplayer.nope=true){
instance_create_depth(x,y,layer,oheartbreak)
instance_destroy(self)
}


self.sprite_index=hpbar_h
if (oplayer.hp<(oplayer.hpmax/2)){
	self.sprite_index=hpbar_h_50percent
}
if (oplayer.hp<(oplayer.hpmax/4)){
	self.sprite_index=hpbar_h_25percent
}
