if (room_get_name(room)==string("lv{oplayer.lvlcount}")){
	currentroom=room
}
show_debug_message(currentroom)