if (oplayer.rf=true){
		self.sprite_index=hpbart	
	
}
if (oplayer.rf=false){
		self.sprite_index=hpbar
	
	
}

