instance_create_layer(x,y,layer,destructablewalldead)
instance_destroy(self)