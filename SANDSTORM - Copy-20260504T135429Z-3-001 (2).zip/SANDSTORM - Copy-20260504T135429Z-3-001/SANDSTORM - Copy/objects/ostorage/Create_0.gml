currentroom=(room)
image_alpha=0