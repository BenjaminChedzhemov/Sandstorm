instance_activate_object(osword)
