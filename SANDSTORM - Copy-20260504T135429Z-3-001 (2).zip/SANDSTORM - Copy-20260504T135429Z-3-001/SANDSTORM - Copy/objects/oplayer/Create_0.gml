///Player code and creation
//I don't know how to do this yet 
hsp=0;
ifr=0
ffall=0;
spring=0;
vsp=0;
grv=0.3-ffall;
walkspeed=5;
facingright=true
hp=100
hpmax=100
tic=0
frcs=0
fra=1
hsplus=0
rf=false
nope=false
lvlcount=1