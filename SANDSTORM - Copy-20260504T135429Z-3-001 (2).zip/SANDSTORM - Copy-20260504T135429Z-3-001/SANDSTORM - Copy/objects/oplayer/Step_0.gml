/// @Every frame
tic--
//Sprite change
if (settingsholder.vfx=1){
if (tic<1){
self.sprite_index=splayert0
}
}
if (settingsholder.vfx=0){
if (tic<-29){
self.sprite_index=splayert0
}
}
//Key pressed

key_left = keyboard_check(vk_left) or keyboard_check(ord("A"));
key_right = keyboard_check(vk_right) or keyboard_check(ord("D"));
key_jump = keyboard_check(vk_space) or keyboard_check (vk_up) or keyboard_check(ord("W"));
key_ability = keyboard_check(vk_down) or keyboard_check(ord("S"));

//Variable
var move = key_right-key_left

//Direction


if(move=1)
{
	image_xscale=1;
	facingright=true
}


if(move=-1)
{
	image_xscale=-1;
	facingright=false
}


//Deciding speed
hsp = move * walkspeed+hsplus;
ifr--

vsp= vsp+grv;
if (place_meeting(x,y+1,owall)) && (key_jump)
{
	vsp=-7.5-spring;
}
//Horizontal collision
if ( place_meeting ( x + hsp , y , owall ) ) 
{
	while(!place_meeting(x+sign(hsp),y,owall))
	{
		x=x+sign(hsp);

	}
	hsp = 0;	
}
//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	speed=0
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
		
	}
	vsp = 0;	
}

//Moving
x = x + hsp;
//Gravity
y = y + vsp;


if (frcs=1){
	fra++
	if (fra>10){
	rf=false
	}
	if (fra>29){
		hsplus=0
		fra=1
		frcs=0
		if (hp<(hpmax-hpmax+1)){
			instance_create_layer(x,y,layer,odeadplayer)
			instance_destroy(self);
		}
	}
	
}

if ( place_meeting ( x  , y+ vsp , owall ) ) 
{

	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
	}
	vsp = 0;	
}


if (settingsholder.vfx=1){
if (fra%10==0){
	self.sprite_index=splayert0
}
if (fra%20==0){
	self.sprite_index=splayerin
}
}


if (hp<(hpmax-hpmax+1)){
	move=1
	if (nope=false){
	vsp=vsp-7
	hsplus=hsplus+7.5
	nope=true
	tic=10
	frcs=1
	instance_destroy(ohpbar);
	instance_destroy(ohpbar_circ);
	instance_destroy(ohpcont);
	}
	self.sprite_index=splayertdead
}


	
	