/// @description Insert description here
// You can write your code in this editor
	self.sprite_index=hpbarc
if (oplayer.hp<(oplayer.hpmax/4)){
	self.sprite_index=hpbarc_25percent
}