///Variable things
bow=0;