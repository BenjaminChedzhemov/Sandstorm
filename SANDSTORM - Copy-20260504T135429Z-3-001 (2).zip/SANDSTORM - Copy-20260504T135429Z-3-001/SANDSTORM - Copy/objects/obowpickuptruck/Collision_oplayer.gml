instance_create_depth(x,y,layer,obowpickupanimation)
instance_destroy(self)