if (instance_exists(sliderepil)){
vfx=sliderepil.onoff
}