randomize()
if (hsplus>0){
	hsplus--
}
if (hsplus<0){
	hsplus++
}
if (iframes>0){
	iframes--
	self.sprite_index=Sandslime_if
}
if (iframes=0){
	self.sprite_index=sLargeSandslime
}
xpos=x
//Step every frame
	stepcount++
if (stepcount>50){
	stepcount=0
}

/// movement
if (irandom_range(1,30)=29)&&storming=0{
storming=1	
}
if (irandom_range(1,50)=29)&&storming=1{
storming=0	
}


if(move=1)
{
	image_xscale=1;
	facingright=true
}


if(move=-1)
{
	image_xscale=-1;
	facingright=false
}


//Deciding speed

hsp = move * walkspeed +hsplus;


vsp= vsp+grv-(storming*.2);

if (place_meeting(x,y+1,owall) && (storming=1))
{
	vsp=-7.5-spring;
}

//Horizontal collision
if ( place_meeting ( x + hsp , y ,owall )){
/// owall move switch
	if (cc=1 && move=-1){
		move=1
		cc=0
		stepcount=0
	}
	if (cc=1 && move=1){
		move=-1
		cc=0
		stepcount=0
	}
	
	
	if (stepcount = 2){
		if(xpos=x){
			stepcount=0
			cc=1
		}
	}
	while(!place_meeting(x+sign(hsp),y,owall))
	{
		x=x+sign(hsp);
	}
	hsp = 0;	
}

x = x + hsp;

//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
	}
	vsp = 0;	
}

//Moving

//Gravity
y = y + vsp;

//Storming Particles.
if (storming=1){
repeat (50){
instance_create_layer(x+(random_range(-50,40)),y-10,layer,osandpartl)
}
}
//HP
if (hp=0){
	instance_destroy(self)
}