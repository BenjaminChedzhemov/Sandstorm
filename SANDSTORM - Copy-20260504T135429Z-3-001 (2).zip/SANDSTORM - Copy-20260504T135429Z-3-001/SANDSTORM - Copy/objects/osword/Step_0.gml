/// sword movement


if (nop=false){
if (oplayer.nope=true){
 instance_destroy(self);
}
}
if nop=false{
if(oplayer.facingright=false)
{
image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),90,270)
image_yscale=-1
}


if(oplayer.facingright=true)
{
	image_yscale=1
	if (oplayer.nope=false){
	if((point_direction(x,y,mouse_x,mouse_y)<180)){
	image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),0,90)
	}
	else{
	image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),270,360)
	}
	}
}
}