nop=false
instance_deactivate_object(self)