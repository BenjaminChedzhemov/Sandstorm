///
if (oplayer.facingright=true){
	
	x=x+10
	if ( place_meeting ( x + hsp , y ,owall )){
		x-=x-10
	}
}
if (oplayer.facingright=false){
	x=x-10
	if ( place_meeting ( x + hsp , y ,owall )){
		x=x+10
	}
}