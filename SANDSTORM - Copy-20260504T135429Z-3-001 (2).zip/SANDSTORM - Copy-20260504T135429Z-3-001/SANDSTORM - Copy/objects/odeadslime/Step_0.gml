//FIX OWALL
hsp = move * walkspeed;


vsp= vsp+grv


	
	
	if (stepcount = 2){
		if(xpos=x){
			stepcount=0
			cc=1
		}
	}
//	while(!place_meeting(x+sign(hsp),y,owall))
//	{
//		x=x+sign(hsp);
//	}
//	hsp = 0;	

x = x + hsp;

//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
	}
	vsp = 0;	
}

//Moving

//Gravity
y = y + vsp;