///Hp loss
if (other.deleting=0){
	if (iframes<=0){
	hp=hp-10
	vsp=vsp-4
	iframes=30
	if (other.image_angle>=90) and (other.image_angle<=270){
		hsplus=hsplus-10
	} else {
	hsplus=hsplus+10
	}
    instance_destroy(other)
}
}