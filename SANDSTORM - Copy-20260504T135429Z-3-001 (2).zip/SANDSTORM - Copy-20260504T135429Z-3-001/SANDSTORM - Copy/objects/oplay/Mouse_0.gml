if (settingsholder.vfx=0){
room_goto(lv1)
}
if (settingsholder.vfx=1){
room_goto(VFXwarning)
}