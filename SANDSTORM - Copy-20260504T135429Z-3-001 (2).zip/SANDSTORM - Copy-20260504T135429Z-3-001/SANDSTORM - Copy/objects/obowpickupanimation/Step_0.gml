///move
repeat(times)
y--;
image_alpha=image_alpha-.02
if(image_alpha=0){

instance_destroy(self);
}
times=times-.1