randomise()

if (iframes>0){
	iframes--
	self.sprite_index=sVileture_ifr
}
if (iframes=0){
	self.sprite_index=sVileture
}
xpos=x
//Step every frame
	stepcount++
if (stepcount>50){
	stepcount=0
}

/// movement
//Moving
if (distance_to_object(oplayer)<200){
	if (res=1){
	spd=6
	frain=30
	res=0
	}
speed=spd
frain--
if (frain<=0){
	spd--
	frain=30
}
if (hsplus>1){
	spd--
	hsplus=0
}
direction=point_direction(x,y,oplayer.x,oplayer.y)
image_angle=direction

} else{
	dir=90
	res=1
	speed=0
if(move=1)
{
	image_xscale=1;
	facingright=true
}


if(move=-1)
{
	image_xscale=-1;
	facingright=false
}


//Deciding speed

hsp = move * walkspeed +hsplus;


vsp= vsp+grv+random_range(1,-2);


//Horizontal collision
if ( place_meeting ( x + hsp , y ,owall )){
/// owall move switch
	if (cc=1 && move=-1){
		move=1
		cc=0
		stepcount=0
	}
	if (cc=1 && move=1){
		move=-1
		cc=0
		stepcount=0
	}
	
	
	if (stepcount = 2){
		if(xpos=x){
			stepcount=0
			cc=1
		}
	}
	while(!place_meeting(x+sign(hsp),y,owall))
	{
		x=x+sign(hsp);
	}
	hsp = 0;	
}

x = x + hsp;

//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
	}
	vsp = 0;	
}
why=y
grv=vsp/2*-1+(10-why*.04)

//Gravity
y = y + vsp;

//HP

vsp= vsp+(grv*2)
}
if (hp=0){
	instance_create_layer(x,y,layer,odeadvlture)
	instance_destroy(self)
}