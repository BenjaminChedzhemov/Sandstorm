///more quirky animation idiocy
if (self.sprite_index=sbowloading){
	self.sprite_index=sbowloaded
}
if (self.sprite_index=sbowunloading){
	self.sprite_index=sbowbase
}