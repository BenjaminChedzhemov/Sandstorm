//sprite change

self.sprite_index=sbowloading
image_alpha=1