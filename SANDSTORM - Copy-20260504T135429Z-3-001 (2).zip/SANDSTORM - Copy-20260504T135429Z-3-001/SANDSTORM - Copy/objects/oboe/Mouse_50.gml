/// Arrows charge
charge=charge+.1
charge=clamp (charge,0,8);

image_alpha=1

