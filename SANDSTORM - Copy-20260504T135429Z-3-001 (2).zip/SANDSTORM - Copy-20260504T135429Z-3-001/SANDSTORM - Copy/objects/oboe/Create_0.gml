holdtime=0
charge=0
cplusmax=0
cando=true
nop=false