/// fire
if (charge != 0){
instance_create_layer(x,y,"arrows",orrow);
charge=0
self.sprite_index=sbowunloading
cando=false
	}
	image_alpha=1