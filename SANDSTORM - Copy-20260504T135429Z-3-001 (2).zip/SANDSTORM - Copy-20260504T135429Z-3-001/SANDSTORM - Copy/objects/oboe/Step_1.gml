image_alpha=0
if (nop=false){
x=oplayer.x-50;
y=oplayer.y;


if(oplayer.facingright=true)
{
x=oplayer.x+50;
}
}

