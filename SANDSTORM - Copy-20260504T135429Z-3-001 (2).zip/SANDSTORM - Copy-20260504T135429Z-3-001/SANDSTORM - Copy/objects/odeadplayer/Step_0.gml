/// @description Insert description here
// You can write your code in this editor
//Deciding speed
vsp= vsp+grv;
//Horizontal collision
if ( place_meeting ( x + hsp , y , owall ) ) 
{
	while(!place_meeting(x+sign(hsp),y,owall))
	{
		x=x+sign(hsp);

	}
	hsp = 0;	
}
//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	speed=0
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
		
	}
	vsp = 0;	
}

//Moving
x = x + hsp;
//Gravity
y = y + vsp;

