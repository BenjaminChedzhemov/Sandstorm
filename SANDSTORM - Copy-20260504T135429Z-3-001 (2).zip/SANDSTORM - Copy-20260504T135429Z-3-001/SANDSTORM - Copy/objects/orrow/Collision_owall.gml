/// Deletion
deleting=true
speed=0
n=true
dmg=false
