///thingys
if(n=false){
	if (instance_exists(oboe)){
		if(pxs=true){
			secs--
		}
		if(pxs=false){
			secs++
		}
	}
}
	image_angle=secs
if(deleting){
ftd--;
image_alpha=image_alpha-.02
}
if(ftd<=0){
	instance_destroy(self)
}

//Movement
vsp=vsp+grv;

//Vertical position
if ( place_meeting ( x , y, owall ) ) 
{
	vsp = 0;	
	speed = 0;
}
//Gravity
y = y + vsp;