///variables
hsp=0
vsp=0
grv=.1
pxs=true
ftd=150
dmg=true
deleting=false
if (instance_exists(oboe)){
	direction = oboe.image_angle
	secs=direction
	image_angle=secs
}
speed=oboe.charge
secs=direction
n=false
if(oplayer.facingright=true){
	pxs=true
}
if(oplayer.facingright=false){
	pxs=false
}
