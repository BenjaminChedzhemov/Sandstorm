
room_goto(ostorage.currentroom)