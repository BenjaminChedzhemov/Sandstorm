/// bow movement


if (nop=false){
if (oplayer.nope=true){
 instance_destroy(self);
}
}
if nop=false{
if(oplayer.facingright=false)
{
image_angle = 45
x=oplayer.x+30
image_xscale=1
}


if(oplayer.facingright=true)
{
	image_angle=45
	image_xscale=-1
	x=oplayer.x-30
}
}

y=oplayer.y