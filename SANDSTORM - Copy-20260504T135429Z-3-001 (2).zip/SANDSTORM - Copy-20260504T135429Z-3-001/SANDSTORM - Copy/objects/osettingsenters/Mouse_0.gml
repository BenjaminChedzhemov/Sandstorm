
room_goto(Settings_Reg)