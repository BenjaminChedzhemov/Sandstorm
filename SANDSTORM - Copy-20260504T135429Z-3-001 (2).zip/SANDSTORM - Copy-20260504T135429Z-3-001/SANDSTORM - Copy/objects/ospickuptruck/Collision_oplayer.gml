instance_create_depth(x,y,layer,ospickupanimation)
instance_destroy(self)