onoff=settingsholder.vfx
x=800