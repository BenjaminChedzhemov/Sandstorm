if (onoff=1){
	onoff=0
} else if (onoff=0){
	onoff=1
}

