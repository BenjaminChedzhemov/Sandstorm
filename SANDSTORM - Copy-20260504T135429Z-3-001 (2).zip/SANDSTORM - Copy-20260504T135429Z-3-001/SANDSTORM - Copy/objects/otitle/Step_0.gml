if (st<101){
	st++
	y=y-(10/(st/2.5))
	image_alpha=image_alpha+.01+(.10/st)
}