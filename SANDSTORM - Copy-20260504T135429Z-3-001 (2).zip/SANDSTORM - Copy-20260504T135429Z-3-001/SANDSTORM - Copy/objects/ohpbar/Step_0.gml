//if (oplayer.rf=true){
//		self.sprite_index=hpbart
	
	
//}

//if (oplayer.rf=false){
//		self.sprite_index=hpbar_bar
	
	
//}

image_xscale=5*oplayer.hp/oplayer.hpmax
