framecount=0
num=1
if (irandom_range(1,2)=2){
	self.sprite_index=ParticleSandslime_2
}