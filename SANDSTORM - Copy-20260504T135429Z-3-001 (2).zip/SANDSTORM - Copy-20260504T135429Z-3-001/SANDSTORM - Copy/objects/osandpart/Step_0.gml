

x+=irandom_range(-5,+5)

	y-=5
framecount++
if (framecount=30){
	instance_destroy(self)
}
