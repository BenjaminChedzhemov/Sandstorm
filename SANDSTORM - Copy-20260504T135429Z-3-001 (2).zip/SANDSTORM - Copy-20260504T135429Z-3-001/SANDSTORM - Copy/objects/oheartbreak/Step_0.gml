/// @description Insert description here
// You can write your code in this editor
fr=fr+1
if (fr>166){
	room_goto(death)
instance_destroy(self)
}