if (instance_exists(oplayer)){
	plyrlvl=oplayer.lvlcount
	show_debug_message("++")
} else {
	show_debug_message("--")
}
if (room_get_name(room)==("lv"+string(plyrlvl))){
	currentroom=room

}
	show_debug_message(currentroom)