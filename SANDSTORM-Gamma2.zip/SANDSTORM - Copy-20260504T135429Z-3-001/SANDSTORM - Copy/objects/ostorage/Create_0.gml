currentroom=(room)
image_alpha=0
plyrlvl=0