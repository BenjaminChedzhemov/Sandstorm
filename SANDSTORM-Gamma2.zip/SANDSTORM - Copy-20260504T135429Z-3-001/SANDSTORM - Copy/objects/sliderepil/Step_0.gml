onoff=settingsholder.vfx
if (onoff=0){
 x=600	
}
if (onoff=1){
 x=800	
}