if (room=lv1){
room_goto_next()
} else {
	room_goto(random_range(9,13))
}
other.x=500
other.y=100
other.lvlcount++