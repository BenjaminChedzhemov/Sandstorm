instance_activate_all()
room_goto(ostorage.currentroom)
instance_activate_all()
instance_deactivate_object(self)