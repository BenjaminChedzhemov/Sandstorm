///Hp loss
if (ifr<1){
if oslimesmall.move=1 {
	hp=hp-10
	move=1
	vsp=vsp-7
	hsplus=hsplus+7.5
	self.sprite_index=splayerda
	tic=10
	ifr=100
	frcs=1
	rf=true
}
if oslimesmall.move=-1 {
	hp=hp-10
	move=1
	vsp=vsp-7
	hsplus=hsplus-7.5
	self.sprite_index=splayerda
	tic=10
	ifr=100
	frcs=1
	rf=true
}
}