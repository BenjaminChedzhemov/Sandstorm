///Hp loss
if (other.deleting=0){
	hp=hp-10
	vsp=vsp-4
	if (other.image_angle>=90) and (other.image_angle<=270){
		hsp=hsp+20
	}
    instance_destroy(other)
}