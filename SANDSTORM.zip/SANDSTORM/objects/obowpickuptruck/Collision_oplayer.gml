///On collision with player dumb thing happens
bow=1;
instance_create_layer(x,y-65,layer,obowpickupanimation)
instance_destroy (self);
