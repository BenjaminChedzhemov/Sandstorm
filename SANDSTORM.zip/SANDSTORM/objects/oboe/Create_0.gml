holdtime=0
