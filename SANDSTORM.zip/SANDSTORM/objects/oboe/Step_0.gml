/// bow movement


if(oplayer.facingright=false)
{
image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),90,270)
}


if(oplayer.facingright=true)
{
	if((point_direction(x,y,mouse_x,mouse_y)<180)){
	image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),0,90)
	}
	else{
	image_angle = clamp (point_direction(x,y,mouse_x,mouse_y),270,360)
	}
}