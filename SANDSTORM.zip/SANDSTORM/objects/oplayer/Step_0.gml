/// @Every frame
//Key pressed
key_left = keyboard_check(vk_left) or keyboard_check(ord("A"));
key_right = keyboard_check(vk_right) or keyboard_check(ord("D"));
key_jump = keyboard_check(vk_space) or keyboard_check (vk_up) or keyboard_check(ord("W"));
key_ability = keyboard_check(vk_down) or keyboard_check(ord("S"));

//Variable
var move = key_right-key_left

//Direction


if(move=1)
{
	image_xscale=1;
	facingright=true
}


if(move=-1)
{
	image_xscale=-1;
	facingright=false
}


//Deciding speed
hsp = move * walkspeed;

vsp= vsp+grv;

if (place_meeting(x,y+1,owall)) && (key_jump)
{
	vsp=-7.5-spring;
}
//Horizontal collision
if ( place_meeting ( x + hsp , y , owall ) ) 
{
	while(!place_meeting(x+sign(hsp),y,owall))
	{
		x=x+sign(hsp);
	}
	hsp = 0;	
}
//Vertical position
if ( place_meeting ( x  , y+ vsp , owall ) ) 
{
	while(!place_meeting(x,y+sign(vsp),owall))
	{
		y=y+sign(vsp);
	}
	vsp = 0;	
}

//Moving
x = x + hsp;
//Gravity
y = y + vsp;