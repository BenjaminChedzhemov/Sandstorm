//@/Player code and creation
//I don't know how to do this yet 
hsp=0;
ffall=0;
spring=0;
vsp=0;
grv=0.3-ffall;
walkspeed=5;
facingright=true